const baseUrl = 'http://localhost:7097';  // Replace with your actual base URL
export default baseUrl;
